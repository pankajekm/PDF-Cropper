PDF Cropper

A libarary to crop boundaries from pdf files, removing unwanted colours and preserves relevant text. Also compresses pdf size.